import './App.css';
import { useEffect, useState } from 'react';

function App() {
  const [type, setType] = useState('pos');
  const [imageLink, setImageLink] = useState(null);
  const [status, setStatus] = useState('active');

  const [locationName, setLocationName] = useState(null);
  const [address, setAddress] = useState(null);
  const [phone, setPhone] = useState(null);
  const [devices, setDevices] = useState([]);
  const [selectedDevice, setSelectedDevice] = useState();
  const [locations, setLocations] = useState([]);

  const handleCreateDevice = async () => {
    if (type != null && imageLink != null && status != null) {
      console.log(type, imageLink, status);
      let response = await fetch('http://localhost:3001/device/createdevice', {
        method: 'post',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: type,
          image: imageLink,
          status: status,
        }),
      });
      console.log(response);
      if (response.status === 201) {
        alert('Device created successfully');
        getDevices();
      }
      response = await response.json();
    } else {
      alert('Please fill all the fields');
    }
  };

  const handleCreateLocation = async () => {
    if (
      locationName != null &&
      address != null &&
      phone != null &&
      devices.length > 0
    ) {
      console.log('selectedDevice', selectedDevice);
      let response = await fetch(
        'http://localhost:3001/location/createlocation',
        {
          method: 'post',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: locationName,
            address: address,
            phone: phone,
            devices: selectedDevice,
          }),
        }
      );
      console.log(response);
      if (response.status === 201) {
        alert('Location created successfully');
        getLocations();
      }
      response = await response.json();
    } else {
      alert('Please fill all the fields');
    }
  };
  const getDevices = async () => {
    let response = await fetch('http://localhost:3001/device/getdevices');
    response = await response.json();
    console.log('devices', response);
    setSelectedDevice(response[0]);
    setDevices([...response]);
  };
  const getLocations = async () => {
    let response = await fetch('http://localhost:3001/location/getlocations');
    response = await response.json();
    console.log('location', response);
    setLocations([...response]);
  };
  const handleDeleteDevice = async (device) => {
    console.log(device);
    let response = await fetch(
      `http://localhost:3001/device/deleteDevice/${device._id}`,
      {
        method: 'POST',
      }
    );
    console.log('deleteResponse', response);
    getLocations();
  };

  useEffect(() => {
    getDevices();
  }, []);
  useEffect(() => {
    getLocations();
  }, []);
  return (
    <div className="App">
      <div>
        <h5>Create Device</h5>
        <label for="cars">Choose Device Type: </label>
        <select
          name="type"
          id="type"
          onChange={(e) => setType(e.target.value)}
          value={type}
        >
          <option value="pos">pos</option>
          <option value="kisok">kisok</option>
          <option value="signage">signage</option>
        </select>

        <label for="Image">Image Link: </label>
        <input
          type="text"
          placeholder="Place the image link"
          value={imageLink}
          onChange={(e) => setImageLink(e.target.value)}
        ></input>

        <label for="Status">Status: </label>
        <select
          name="status"
          id="status"
          onChange={(e) => setStatus(e.target.value)}
          value={status}
        >
          <option value="active">active</option>
          <option value="inactive">inactive</option>
        </select>

        <button onClick={handleCreateDevice}>Create Device</button>
      </div>

      <div>
        <h5>Create Location</h5>

        <label for="name">Name: </label>
        <input
          type="text"
          placeholder="Enter the location name"
          value={locationName}
          onChange={(e) => setLocationName(e.target.value)}
        ></input>

        <label for="address">Address: </label>
        <input
          type="text"
          placeholder="Enter the Address"
          value={address}
          onChange={(e) => setAddress(e.target.value)}
        ></input>

        <label for="phone">Phone: </label>
        <input
          type="number"
          placeholder="Enter the Phone"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
        ></input>

        <label for="devices">Device: </label>
        <select
          name="devices"
          id="devices"
          onChange={(e) => setSelectedDevice(e.target.value)}
        >
          {devices?.map((device) => {
            return (
              <option value={device._id}>
                {device.type} {device.serialNumber} {device.status}
              </option>
            );
          })}
        </select>
        <button onClick={handleCreateLocation}>Create Location</button>
      </div>
      <div>
        <table>
          <tr>
            <td>Address</td>
            <td>Name</td>
            <td>Phone</td>
            <td>Devices</td>
          </tr>
          {locations.map((location) => {
            return (
              <tr>
                <td>{location.address}</td>
                <td>{location.name}</td>
                <td>{location.phone}</td>

                <td>
                  {location?.devices?.map((device) => {
                    return (
                      <>
                        <p>{device.serialNumber}</p>
                        <p>{device.status}</p>
                        <p>{device.type}</p>
                        <p>
                          <img src={device.image} alt=" of device" />
                        </p>
                        <button onClick={() => handleDeleteDevice(device)}>
                          Delete Device
                        </button>
                      </>
                    );
                  })}
                </td>
              </tr>
            );
          })}
        </table>
      </div>
    </div>
  );
}

export default App;
