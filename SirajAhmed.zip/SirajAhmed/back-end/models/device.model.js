const mongoose = require('mongoose');

const deviceSchema = mongoose.Schema({
  serialNumber: {
    type: String,
    required: true,
    trim: true,
  },
  type: {
    type: String,
    required: true,
    enum: ['pos', 'kisok', 'signage'],
  },
  image: {
    type: String,
    required: true,
  },
  status: {
    type: String,
    required: true,
    enum: ['active', 'inactive'],
  },
});

const Device = mongoose.model('Device', deviceSchema);

module.exports = Device;
