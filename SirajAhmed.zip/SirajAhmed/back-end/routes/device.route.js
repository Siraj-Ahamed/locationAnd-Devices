const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');
const Device = require('../models/device.model');
const Location = require('../models/location.model');

router.post('/createdevice', async function (req, res) {
  const { type, image, status } = req.body;
  try {
    const response = await Device.create({
      serialNumber: uuidv4(),
      type: type,
      image: image,
      status: status,
    });
    return res.status(201).json(response);
  } catch (error) {
    console.log(error);
    return res.status(500).json({ Error: error });
  }
});

router.get('/getdevices', async function (req, res) {
  try {
    const devices = await Device.find();
    return res.status(200).json(devices);
  } catch (error) {
    return res.status(500).json({ Error: error });
  }
});

router.post('/deleteDevice/:deviceID', async function (req, res) {
  const deviceId = req.params.deviceID;
  try {
    const response = await Location.findOneAndUpdate(
      { devices: deviceId },
      { devices: null }
    );
    console.log(response);
    return res.status(201).json(response);
  } catch (error) {
    console.log(error);
    return res.status(500).json({ Error: error });
  }
});

module.exports = router;
