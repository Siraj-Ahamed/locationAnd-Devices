const express = require('express');
const router = express.Router();
const Location = require('../models/location.model');

router.post('/createlocation', async function (req, res) {
  const { devices, name, address, phone } = req.body;
  console.log(req.body);
  try {
    const response = await Location.create({
      name: name,
      address: address,
      phone: phone,
      devices: devices,
    });
    return res.status(201).json({ response });
  } catch (error) {
    return res.status(500).json({ Error: error });
  }
});

router.get('/getlocations', async function (req, res) {
  try {
    const response = await Location.find().populate('devices');
    console.log(response);
    return res.status(200).json(response);
  } catch (error) {
    return res.status(500).json({ Error: error });
  }
});

module.exports = router;
